# learning-solid-pp
 Repositório de atividade de Padrões de Projeto
