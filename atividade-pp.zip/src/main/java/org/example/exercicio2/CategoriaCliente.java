package org.example.exercicio2;

public interface CategoriaCliente {

    double desconto();
}
