package org.example.exercicio4;

public class PassaroVoador extends Passaro {

    public void voar() {
        // lógica de voar
    }
}
