package org.example.exercicio4;

public class Avestruz extends PassaroVoador {

    public void voar(){
        // lógica de voar
    }
}
