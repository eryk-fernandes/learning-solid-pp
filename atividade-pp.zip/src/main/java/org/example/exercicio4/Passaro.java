package org.example.exercicio4;

//Modifique o código seguindo o Princípio da Substituição de Liskov.

public class Passaro {

}
