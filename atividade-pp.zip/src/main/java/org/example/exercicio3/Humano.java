package org.example.exercicio3;

public class Humano implements Trabalhar, Comer {
    @Override
    public void trabalhar() {
        // Lógica de trabalhar
    }

    @Override
    public void comer() {
        // Lógica de comer
    }
}
