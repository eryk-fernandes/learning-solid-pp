package org.example.exercicio3;


public class Robo implements Trabalhar {

    @Override
    public void trabalhar() {
        // Lógica de trabalhar
    }

}
