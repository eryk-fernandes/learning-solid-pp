package org.example.exercicio3;

public interface Comer {

    void comer();
}
