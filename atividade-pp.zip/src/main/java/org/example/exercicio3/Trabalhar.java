package org.example.exercicio3;

public interface Trabalhar {

    void trabalhar();
}
