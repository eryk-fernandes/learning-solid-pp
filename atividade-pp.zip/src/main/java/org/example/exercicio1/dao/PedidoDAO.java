package org.example.exercicio1.dao;

public class PedidoDAO {

    public void salvarPedido(){
        // Lógica para salvar no banco
    }
}
