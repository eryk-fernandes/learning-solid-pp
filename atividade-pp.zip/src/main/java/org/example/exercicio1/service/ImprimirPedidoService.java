package org.example.exercicio1.service;

public class ImprimirPedidoService {

    public void imprimirPedido(){
        // Lógica para imprimir pedido
    }
}
