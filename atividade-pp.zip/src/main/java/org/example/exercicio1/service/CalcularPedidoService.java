package org.example.exercicio1.service;

public class CalcularPedidoService {

    public void calculaTotal(){
        // Lógica de cálculo
    }
}
